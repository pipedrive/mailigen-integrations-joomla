<?php

defined('_JEXEC') or die;

/**
 * Helper for mod_mailigen
 */
class ModMailigenHelper
{
	
}
