<?php
/**
 * @copyright   Copyright (c) 2018 Mailigen. All rights reserved.
 * @license     GNU General Public License version 3 or later.
 */

// no direct access
defined('_JEXEC') or die('Restricted Access');

/**
 * Helper for mod_mailigen
 */
class ModMailigenHelper
{
	
}
