<?php
/**
 * @copyright   Copyright (c) 2018 Mailigen. All rights reserved.
 * @license     GNU General Public License version 3 or later.
 */

// no direct access
defined('_JEXEC') or die('Restricted Access');

class MailigenControllerSubscribers extends MailigenController {

	public function __construct($config = array()) {
		parent::__construct($config);        
	}

    public function goToLists() {
        $this->setRedirect('index.php?option=com_mailigen&view=lists');
    }

}
